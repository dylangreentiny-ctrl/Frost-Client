"""
Frost Client - standalone desktop app
A clean, light blue/white FPS-tier switcher for vanilla Minecraft Java Edition.

This app does NOT modify Minecraft's game files or inject code. It simply
edits Minecraft's own settings file (options.txt) with values Minecraft
already understands - render distance, particles, fps cap, graphics mode,
clouds, view bobbing, etc. That means it's 100% vanilla-safe and works on
any Minecraft install without installing Fabric/Forge or any mod loader.

Run with:  python frost_client.py
(Requires Python 3.8+, uses only the standard library - no installs needed.)
"""

import os
import sys
import tkinter as tk
from tkinter import messagebox

# ---------------------------------------------------------------------------
# Theme
# ---------------------------------------------------------------------------
BG_DARK = "#0E1B2A"      # deep frost navy
PANEL = "#E8F4FB"        # icy white-blue
ACCENT = "#7FD3F5"       # light blue
ACCENT_DARK = "#2E86AB"  # deeper blue for selected/hover
TEXT_DARK = "#0E1B2A"
WHITE = "#FFFFFF"

FONT_TITLE = ("Segoe UI", 18, "bold")
FONT_SUB = ("Segoe UI", 10)
FONT_TIER = ("Segoe UI", 12, "bold")
FONT_DESC = ("Segoe UI", 9)

# ---------------------------------------------------------------------------
# Tiers - each is strictly more aggressive than the last.
# Keys map directly to Minecraft's options.txt setting names.
# ---------------------------------------------------------------------------
TIERS = [
    {
        "name": "Chill",
        "level": 1,
        "desc": "Light optimization. Looks almost identical to vanilla.",
        "settings": {
            "renderDistance": "10",
            "particles": "1",       # 0=all 1=decreased 2=minimal
            "maxFps": "240",
            "graphicsMode": "1",    # 0=fast 1=fancy 2=fabulous
            "cloudRender": "1",     # 0=fast render
            "ao": "2",
            "viewBobbing": "true",
        },
    },
    {
        "name": "Freeze",
        "level": 2,
        "desc": "Moderate optimization. Slightly reduced visuals.",
        "settings": {
            "renderDistance": "8",
            "particles": "1",
            "maxFps": "260",
            "graphicsMode": "1",
            "cloudRender": "0",
            "ao": "1",
            "viewBobbing": "false",
        },
    },
    {
        "name": "Deep Freeze",
        "level": 3,
        "desc": "Heavy optimization. Trims particles and clouds hard.",
        "settings": {
            "renderDistance": "6",
            "particles": "2",
            "maxFps": "360",
            "graphicsMode": "0",
            "cloudRender": "2",     # off
            "ao": "0",
            "viewBobbing": "false",
        },
    },
    {
        "name": "Absolute Zero",
        "level": 4,
        "desc": "Maximum FPS. Most visually stripped down tier.",
        "settings": {
            "renderDistance": "4",
            "particles": "2",
            "maxFps": "0",          # unlimited
            "graphicsMode": "0",
            "cloudRender": "2",
            "ao": "0",
            "viewBobbing": "false",
        },
    },
]

# ---------------------------------------------------------------------------
# Locate Minecraft's options.txt across platforms
# ---------------------------------------------------------------------------
def find_options_file():
    home = os.path.expanduser("~")
    candidates = [
        os.path.join(home, "AppData", "Roaming", ".minecraft", "options.txt"),  # Windows
        os.path.join(home, "Library", "Application Support", "minecraft", "options.txt"),  # Mac
        os.path.join(home, ".minecraft", "options.txt"),  # Linux
    ]
    for path in candidates:
        if os.path.isfile(path):
            return path
    return None


def apply_tier(options_path, settings):
    """Read options.txt, replace/insert the given keys, write it back."""
    lines = []
    if os.path.isfile(options_path):
        with open(options_path, "r", encoding="utf-8", errors="ignore") as f:
            lines = f.readlines()

    keys_written = set()
    new_lines = []
    for line in lines:
        if ":" in line:
            key = line.split(":", 1)[0]
            if key in settings:
                new_lines.append(f"{key}:{settings[key]}\n")
                keys_written.add(key)
                continue
        new_lines.append(line)

    for key, value in settings.items():
        if key not in keys_written:
            new_lines.append(f"{key}:{value}\n")

    with open(options_path, "w", encoding="utf-8") as f:
        f.writelines(new_lines)


# ---------------------------------------------------------------------------
# UI
# ---------------------------------------------------------------------------
class FrostApp(tk.Tk):
    def __init__(self):
        super().__init__()
        self.title("Frost Client")
        self.geometry("360x430")
        self.resizable(False, False)
        self.configure(bg=BG_DARK)

        self.options_path = find_options_file()

        self._build_header()
        self._build_panel()
        self._build_status()

    def _build_header(self):
        header = tk.Frame(self, bg=BG_DARK)
        header.pack(fill="x", pady=(18, 6))
        tk.Label(header, text="❄ Frost Client", font=FONT_TITLE,
                 bg=BG_DARK, fg=ACCENT).pack()
        tk.Label(header, text="Select a performance tier", font=FONT_SUB,
                 bg=BG_DARK, fg=WHITE).pack(pady=(2, 0))

    def _build_panel(self):
        panel = tk.Frame(self, bg=PANEL, highlightbackground=ACCENT_DARK,
                          highlightthickness=2)
        panel.pack(padx=20, pady=10, fill="both", expand=True)

        for tier in TIERS:
            self._build_tier_row(panel, tier)

    def _build_tier_row(self, parent, tier):
        row = tk.Frame(parent, bg=PANEL)
        row.pack(fill="x", padx=14, pady=8)

        btn = tk.Button(
            row,
            text=f"{tier['level']}.  {tier['name']}",
            font=FONT_TIER,
            bg=ACCENT, fg=TEXT_DARK,
            activebackground=ACCENT_DARK, activeforeground=WHITE,
            relief="flat", bd=0, padx=10, pady=6,
            command=lambda t=tier: self._on_select(t),
        )
        btn.pack(fill="x")
        tk.Label(row, text=tier["desc"], font=FONT_DESC, bg=PANEL,
                 fg=ACCENT_DARK, wraplength=290, justify="left").pack(
            anchor="w", pady=(3, 0))

    def _build_status(self):
        self.status_var = tk.StringVar()
        if self.options_path:
            self.status_var.set(f"Found Minecraft settings at:\n{self.options_path}")
        else:
            self.status_var.set(
                "Couldn't find a Minecraft install automatically.\n"
                "Launch Minecraft at least once, then reopen Frost Client."
            )
        tk.Label(self, textvariable=self.status_var, font=("Segoe UI", 8),
                 bg=BG_DARK, fg="#8FB4CC", wraplength=340, justify="center").pack(
            pady=(0, 12))

    def _on_select(self, tier):
        if not self.options_path:
            messagebox.showerror(
                "Frost Client",
                "No Minecraft installation was found.\n\n"
                "Launch Minecraft Java Edition at least once so it creates "
                "its settings file, then reopen Frost Client."
            )
            return
        try:
            apply_tier(self.options_path, tier["settings"])
            messagebox.showinfo(
                "Frost Client",
                f"{tier['name']} tier applied!\n\n"
                "Restart Minecraft (or reopen the game) for the new "
                "settings to take effect."
            )
        except Exception as e:
            messagebox.showerror("Frost Client", f"Couldn't apply settings:\n{e}")


if __name__ == "__main__":
    app = FrostApp()
    app.mainloop()
