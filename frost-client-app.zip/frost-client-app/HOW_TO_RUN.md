# Frost Client (standalone app)

A small light blue/white desktop app with a snowflake theme, letting you
pick one of 4 tiers — Chill, Freeze, Deep Freeze, Absolute Zero — to boost
your vanilla Minecraft FPS. It works by editing Minecraft's own settings
file, so it's 100% vanilla and safe on any server (no mod loader needed).

## How to run it

1. Install **Python 3** if you don't already have it: https://python.org/downloads
   (On Windows, check "Add Python to PATH" during install.)
2. Download `frost_client.py` from this package.
3. Double-click it, or run from a terminal:
   - Windows: `python frost_client.py`
   - Mac/Linux: `python3 frost_client.py`
4. The app auto-detects your Minecraft settings file. Click a tier to
   apply it, then restart Minecraft.

## Turning it into a real .exe / .app (optional)

If you want a proper double-clickable application icon instead of running
a script, on your own machine (with internet) run:

```
pip install pyinstaller
pyinstaller --onefile --windowed --name "Frost Client" frost_client.py
```

This creates a standalone executable in the `dist` folder — no Python
needed to run it afterward. On Windows this makes `Frost Client.exe`; on
Mac it makes `Frost Client.app`.

## What each tier changes

| Tier | Render Distance | Particles | FPS Cap | Graphics | Clouds |
|------|-----------------|-----------|---------|----------|--------|
| 1. Chill | 10 chunks | Decreased | 240 | Fancy | Fancy |
| 2. Freeze | 8 chunks | Decreased | 260 | Fancy | Fast |
| 3. Deep Freeze | 6 chunks | Minimal | 360 | Fast | Off |
| 4. Absolute Zero | 4 chunks | Minimal | Unlimited | Fast | Off |

All values are standard vanilla Minecraft options — nothing injected,
nothing that could get flagged on multiplayer servers.
